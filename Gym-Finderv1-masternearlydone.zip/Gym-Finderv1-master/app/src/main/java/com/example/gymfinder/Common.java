package com.example.gymfinder;

import com.example.gymfinder.Model.Results;
import com.example.gymfinder.Remote.IGoogleAPIService;
import com.example.gymfinder.Remote.RetrofitClient;

public class Common {
    private static  final String GOOGLE_API_URL="https://maps.googleapis.com/";
    public static Results currentResult;


    public static IGoogleAPIService getGoogleAPIService(){

        return RetrofitClient.getClient(GOOGLE_API_URL).create(IGoogleAPIService.class);
    }
}
