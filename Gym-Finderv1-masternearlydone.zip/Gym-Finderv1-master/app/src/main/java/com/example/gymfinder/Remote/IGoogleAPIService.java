package com.example.gymfinder.Remote;

import com.example.gymfinder.Model.MyPlaces;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public interface IGoogleAPIService {
    @GET
    Call<MyPlaces> getNearByPlaces (@Url String Url);
}
